module.exports = {
    MONGODB: 'mongodb+srv://Aimdep:DspR8vbjTAezA88p@cluster0.xeinj.mongodb.net/media?retryWrites=true&w=majority',
    SECRET_KEY: 'some very secret key'
};